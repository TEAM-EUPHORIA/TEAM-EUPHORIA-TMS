using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using TMS.Data.Context;

namespace TMS.Data.Factories
{
    public class AppDbContextFactory : IDesignTimeDbContextFactory<AppDbContext>
    {
        public AppDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
            var connectionString = Environment.GetEnvironmentVariable("SQLSERVER_MOVIES_LOCAL_CONNSTR");
            optionsBuilder.UseSqlServer(connectionString
                                        ?? throw new NullReferenceException(
                                            $"Connection string is not got from environment {nameof(connectionString)}"));

            return new AppDbContext(optionsBuilder.Options);
        }
    }
}