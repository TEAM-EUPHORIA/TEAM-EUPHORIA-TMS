﻿using System;
using System.Collections.Generic;

namespace TMS.Data
{
    public partial class CourseTraineeMapping
    {
        /// <summary>
        /// Primary Id of course trainee mapping 
        /// </summary>
        public int CourseTraineeMappingId { get; set; }
        /// <summary>
        /// Id of the course 
        /// </summary>
        public int CourseId { get; set; }
        /// <summary>
        /// User Id of the trainee belongs to the course 
        /// </summary>
        public int TraineeId { get; set; }
        public string CreatedBy { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual Course Course { get; set; } = null!;
        public virtual User Trainee { get; set; } = null!;
    }
}
