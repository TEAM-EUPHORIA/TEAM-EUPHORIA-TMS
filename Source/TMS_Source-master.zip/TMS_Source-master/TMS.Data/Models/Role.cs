﻿using System;
using System.Collections.Generic;

namespace TMS.Data
{
    public partial class Role
    {
        public Role()
        {
            Users = new HashSet<User>();
        }

        /// <summary>
        /// Primary Id for the role 
        /// </summary>
        public int RoleId { get; set; }
        /// <summary>
        /// Name of the role 
        /// </summary>
        public string RoleName { get; set; } = null!;
        public string CreatedBy { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual ICollection<User> Users { get; set; }
    }
}
