﻿using System;
using System.Collections.Generic;

namespace TMS.Data
{
    public partial class Course
    {
        public Course()
        {
            CourseFeedbacks = new HashSet<CourseFeedback>();
            CourseTraineeMappings = new HashSet<CourseTraineeMapping>();
            Topics = new HashSet<Topic>();
            TraineeFeedbacks = new HashSet<TraineeFeedback>();
        }

        /// <summary>
        /// Primary Id for each course 
        /// </summary>
        public int CourseId { get; set; }
        /// <summary>
        /// Name of the course 
        /// </summary>
        public string CourseName { get; set; } = null!;
        /// <summary>
        /// Description of the course 
        /// </summary>
        public string CourseDescription { get; set; } = null!;
        /// <summary>
        /// Duration of the course 
        /// </summary>
        public string CourseDuration { get; set; } = null!;
        /// <summary>
        /// Trainer (user id) of the course 
        /// </summary>
        public int TrainerId { get; set; }
        public string CreatedBy { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual User Trainer { get; set; } = null!;
        public virtual ICollection<CourseFeedback> CourseFeedbacks { get; set; }
        public virtual ICollection<CourseTraineeMapping> CourseTraineeMappings { get; set; }
        public virtual ICollection<Topic> Topics { get; set; }
        public virtual ICollection<TraineeFeedback> TraineeFeedbacks { get; set; }
    }
}
