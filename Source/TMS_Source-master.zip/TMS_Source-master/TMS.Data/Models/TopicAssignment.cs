﻿using System;
using System.Collections.Generic;

namespace TMS.Data
{
    public partial class TopicAssignment
    {
        /// <summary>
        /// Primary Assignment Id for Particular topic 
        /// </summary>
        public int AssignmentId { get; set; }
        /// <summary>
        /// Topic Id for the assignment 
        /// </summary>
        public int TopicId { get; set; }
        /// <summary>
        /// Document for the assignment 
        /// </summary>
        public byte[] AnswerDocument { get; set; } = null!;
        /// <summary>
        /// User Id of trainer or trainee (who submitted the document) 
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// Status of the document submission
        /// </summary>
        public int AssignmentStatusId { get; set; }
        public string CreatedBy { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual AssignmentStatus AssignmentStatus { get; set; } = null!;
        public virtual Topic Topic { get; set; } = null!;
        public virtual User User { get; set; } = null!;
    }
}
