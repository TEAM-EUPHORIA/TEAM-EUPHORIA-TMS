﻿using System;
using System.Collections.Generic;

namespace TMS.Data
{
    public partial class Department
    {
        public Department()
        {
            Users = new HashSet<User>();
        }

        /// <summary>
        /// Primary Id for the department 
        /// </summary>
        public int DepartmentId { get; set; }
        /// <summary>
        /// Name of the department 
        /// </summary>
        public string DepartmentName { get; set; } = null!;
        public string CreatedBy { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual ICollection<User> Users { get; set; }
    }
}
