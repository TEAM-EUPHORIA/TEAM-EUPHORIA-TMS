﻿using System;
using System.Collections.Generic;

namespace TMS.Data
{
    public partial class Mom
    {
        /// <summary>
        /// Primary Mom Id
        /// </summary>
        public int MomId { get; set; }
        /// <summary>
        /// Id of the review
        /// </summary>
        public int ReviewId { get; set; }
        /// <summary>
        /// Id of MOM status
        /// </summary>
        public int MomStatusId { get; set; }
        /// <summary>
        /// Review meeting notes 
        /// </summary>
        public string MeetingNotes { get; set; } = null!;
        /// <summary>
        /// Agenda of the review
        /// </summary>
        public string Agenda { get; set; } = null!;
        /// <summary>
        /// Purpose of the review meeting 
        /// </summary>
        public string PurposeOfMeeting { get; set; } = null!;
        public string CreatedBy { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual MomStatus MomStatus { get; set; } = null!;
        public virtual Review Review { get; set; } = null!;
    }
}
