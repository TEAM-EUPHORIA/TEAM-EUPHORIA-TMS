﻿using System;
using System.Collections.Generic;

namespace TMS.Data
{
    public partial class CourseFeedback
    {
        /// <summary>
        /// Primary Id of the course feddback 
        /// </summary>
        public int CourseFeedbackId { get; set; }
        /// <summary>
        /// Id of the course 
        /// </summary>
        public int CourseId { get; set; }
        /// <summary>
        /// User id of Trainee  
        /// </summary>
        public int TraineeId { get; set; }
        /// <summary>
        /// Feedback content about the course  
        /// </summary>
        public string FeedbackContent { get; set; } = null!;
        /// <summary>
        /// Ratings of the course by the trainee 
        /// </summary>
        public double Ratings { get; set; }
        public string CreatedBy { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual Course Course { get; set; } = null!;
        public virtual User Trainee { get; set; } = null!;
    }
}
