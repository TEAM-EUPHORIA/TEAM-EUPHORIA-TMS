﻿using System;
using System.Collections.Generic;

namespace TMS.Data
{
    public partial class Topic
    {
        public Topic()
        {
            TopicAssignments = new HashSet<TopicAssignment>();
            TopicAttendances = new HashSet<TopicAttendance>();
        }

        /// <summary>
        /// Primary Topic Id for Particular course 
        /// </summary>
        public int TopicId { get; set; }
        /// <summary>
        /// Topic name of the course 
        /// </summary>
        public string TopicName { get; set; } = null!;
        /// <summary>
        /// Topic description of the course 
        /// </summary>
        public string TopicContent { get; set; } = null!;
        /// <summary>
        /// Course Id of the topic 
        /// </summary>
        public int CourseId { get; set; }
        /// <summary>
        /// Duration of the course 
        /// </summary>
        public string TopicDuration { get; set; } = null!;
        public string? CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual Course Course { get; set; } = null!;
        public virtual ICollection<TopicAssignment> TopicAssignments { get; set; }
        public virtual ICollection<TopicAttendance> TopicAttendances { get; set; }
    }
}
