﻿using System;
using System.Collections.Generic;

namespace TMS.Data
{
    public partial class TopicAttendance
    {
        /// <summary>
        /// Primary Attendance Id for Particular topic 
        /// </summary>
        public int AttendanceId { get; set; }
        /// <summary>
        /// Topic Id for Attendance
        /// </summary>
        public int TopicId { get; set; }
        /// <summary>
        /// Status of the Attendance
        /// </summary>
        public int AttendanceStatusId { get; set; }
        /// <summary>
        /// User id of Trainer or Trainee (who marked the attendance) 
        /// </summary>
        public int UserId { get; set; }
        public string CreatedBy { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual AttendanceStatus AttendanceStatus { get; set; } = null!;
        public virtual Topic Topic { get; set; } = null!;
        public virtual User User { get; set; } = null!;
    }
}
