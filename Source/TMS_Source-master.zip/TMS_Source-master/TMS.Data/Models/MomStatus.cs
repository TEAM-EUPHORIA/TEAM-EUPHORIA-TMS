﻿using System;
using System.Collections.Generic;

namespace TMS.Data
{
    public partial class MomStatus
    {
        public MomStatus()
        {
            Moms = new HashSet<Mom>();
        }

        /// <summary>
        /// Primary Mom status Id
        /// </summary>
        public int MomStatusId { get; set; }
        /// <summary>
        /// Name of the Mom status 
        /// </summary>
        public string Name { get; set; } = null!;
        public string CreatedBy { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual ICollection<Mom> Moms { get; set; }
    }
}
