﻿using System;
using System.Collections.Generic;

namespace TMS.Data
{
    public partial class AttendanceStatus
    {
        public AttendanceStatus()
        {
            TopicAttendances = new HashSet<TopicAttendance>();
        }

        /// <summary>
        /// Primary Id of the attendance status
        /// </summary>
        public int AttendanceStatusId { get; set; }
        /// <summary>
        /// Name of the Attendance status 
        /// </summary>
        public string Name { get; set; } = null!;
        public string CreatedBy { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual ICollection<TopicAttendance> TopicAttendances { get; set; }
    }
}
