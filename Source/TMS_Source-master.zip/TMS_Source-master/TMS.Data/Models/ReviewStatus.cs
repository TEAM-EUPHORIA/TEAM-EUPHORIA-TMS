﻿using System;
using System.Collections.Generic;

namespace TMS.Data
{
    public partial class ReviewStatus
    {
        public ReviewStatus()
        {
            Reviews = new HashSet<Review>();
        }

        /// <summary>
        /// Primary Review status Id
        /// </summary>
        public int ReviewStatusId { get; set; }
        /// <summary>
        /// Name of the status 
        /// </summary>
        public string Name { get; set; } = null!;
        public string CreatedBy { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual ICollection<Review> Reviews { get; set; }
    }
}
