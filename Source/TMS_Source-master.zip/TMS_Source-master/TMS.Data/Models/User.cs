﻿using System;
using System.Collections.Generic;

namespace TMS.Data
{
    public partial class User
    {
        public User()
        {
            CourseFeedbacks = new HashSet<CourseFeedback>();
            CourseTraineeMappings = new HashSet<CourseTraineeMapping>();
            Courses = new HashSet<Course>();
            ReviewReviewers = new HashSet<Review>();
            ReviewTrainees = new HashSet<Review>();
            TopicAssignments = new HashSet<TopicAssignment>();
            TopicAttendances = new HashSet<TopicAttendance>();
            TraineeFeedbackTrainees = new HashSet<TraineeFeedback>();
            TraineeFeedbackTrainers = new HashSet<TraineeFeedback>();
        }

        /// <summary>
        /// Primary Id for each user 
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// Name of the user 
        /// </summary>
        public string Name { get; set; } = null!;
        /// <summary>
        /// Email of the user 
        /// </summary>
        public string Email { get; set; } = null!;
        /// <summary>
        /// Username of the user 
        /// </summary>
        public string UserName { get; set; } = null!;
        /// <summary>
        /// Password of the user 
        /// </summary>
        public string Password { get; set; } = null!;
        /// <summary>
        /// Role Id of the user 
        /// </summary>

        public int RoleId { get; set; }
        /// <summary>
        /// Department id of the user 
        /// </summary>
        public int? DepartmentId { get; set; }
        /// <summary>
        /// Profile image of the user 
        /// </summary>
        public byte[] ProfileImage { get; set; } = null!;
        public string CreatedBy { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }

        public virtual Department? Department { get; set; }
        public virtual Role Role { get; set; } = null!;
        public virtual ICollection<CourseFeedback> CourseFeedbacks { get; set; }
        public virtual ICollection<CourseTraineeMapping> CourseTraineeMappings { get; set; }
        public virtual ICollection<Course> Courses { get; set; }
        public virtual ICollection<Review> ReviewReviewers { get; set; }
        public virtual ICollection<Review> ReviewTrainees { get; set; }
        public virtual ICollection<TopicAssignment> TopicAssignments { get; set; }
        public virtual ICollection<TopicAttendance> TopicAttendances { get; set; }
        public virtual ICollection<TraineeFeedback> TraineeFeedbackTrainees { get; set; }
        public virtual ICollection<TraineeFeedback> TraineeFeedbackTrainers { get; set; }
    }
}
