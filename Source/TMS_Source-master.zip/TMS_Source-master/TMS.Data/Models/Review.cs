﻿using System;
using System.Collections.Generic;

namespace TMS.Data
{
    public partial class Review
    {
        public Review()
        {
            Moms = new HashSet<Mom>();
        }

        /// <summary>
        /// primary Id of the Review 
        /// </summary>
        public int ReviewId { get; set; }
        /// <summary>
        /// User Id of the reviewer 
        /// </summary>
        public int ReviewerId { get; set; }
        /// <summary>
        /// User Id of the trainee 
        /// </summary>
        public int TraineeId { get; set; }
        /// <summary>
        /// Date of the review Schedule 
        /// </summary>
        public string ReviewDate { get; set; } = null!;
        /// <summary>
        /// Time of the review Schedule 
        /// </summary>
        public string ReviewTime { get; set; } = null!;
        /// <summary>
        /// Mode of the review 
        /// </summary>
        public string Mode { get; set; } = null!;
        /// <summary>
        /// Status of the review 
        /// </summary>
        public int ReviewStatusId { get; set; }
        public string CreatedBy { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? UpdateOn { get; set; }

        public virtual ReviewStatus ReviewStatus { get; set; } = null!;
        public virtual User Reviewer { get; set; } = null!;
        public virtual User Trainee { get; set; } = null!;
        public virtual ICollection<Mom> Moms { get; set; }
    }
}
