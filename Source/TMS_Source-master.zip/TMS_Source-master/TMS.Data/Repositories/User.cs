using TMS.Data.Context;
using TMS.Data.Interface;

namespace TMS.Data.Repositories
{
    public class User : IUser
    {
        private readonly AppDbContext _context;

        public User(AppDbContext context)
        {
            _context = context;
        }
        bool IUser.AddUser(Data.User user)
        {
            bool result = false;
            if (user != null)
            {
                _context.Add(user);
                _context.SaveChanges();
                result = true;
            }
            return result;
        }

        bool IUser.DisableUser(int id, Data.User user)
        {
            throw new NotImplementedException();
        }

        Data.User IUser.GetById(int id)
        {
            return _context.Users.Find(id);
        }

        List<Data.User> IUser.GetUsersByDepartment(int dept_id)
        {
            return _context.Users.Where(e => e.DepartmentId == dept_id).ToList();
        }

        List<Data.User> IUser.GetUsersByRole(int role_id)
        {
            return _context.Users.Where(e => e.RoleId == role_id).ToList();
        }

        bool IUser.UpdateUser(int id, Data.User user)
        {
            bool result = false;
            if (user != null && user.UserId == id)
            {
                _context.Update(user);
                _context.SaveChanges();
                result = true;
            }
            return result;
        }
    }
}