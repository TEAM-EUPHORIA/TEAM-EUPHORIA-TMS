using TMS.Data.Context;
using TMS.Data.Interface;
using TMS.Data.Models;

namespace TMS.Data.Repositories
{
    public class Department : IDepartment
    {
        private readonly AppDbContext _context;

        public Department(AppDbContext context)
        {
            _context = context;
        }
        bool AddDepartment(Department dept)
        {
            bool result = false;
            if (dept != null)
            {
                _context.Add(dept);
                _context.SaveChanges();
                result = true;
            }
            return result;
        }
        bool UpdateDepartment(int dept_id, Department dept){
            bool result = false;
            if (dept != null && Department.DepartmentId == dept_id)
            {
                _context.Update(dept);
                _context.SaveChanges();
                result = true;
            }
            return result;
        }

        List<Department> GetDepartment(int dept_id)
        {
            return _context.Department.ToList();
        }
    }
}