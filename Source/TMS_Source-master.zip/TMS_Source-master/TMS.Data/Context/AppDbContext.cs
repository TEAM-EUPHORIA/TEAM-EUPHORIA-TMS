using Microsoft.EntityFrameworkCore;

namespace TMS.Data.Context
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }

        public virtual DbSet<AssignmentStatus> AssignmentStatuses { get; set; } = null!;
        public virtual DbSet<AttendanceStatus> AttendanceStatuses { get; set; } = null!;
        public virtual DbSet<Course> Courses { get; set; } = null!;
        public virtual DbSet<CourseFeedback> CourseFeedbacks { get; set; } = null!;
        public virtual DbSet<CourseTraineeMapping> CourseTraineeMappings { get; set; } = null!;
        public virtual DbSet<Department> Departments { get; set; } = null!;
        public virtual DbSet<Mom> Moms { get; set; } = null!;
        public virtual DbSet<MomStatus> MomStatuses { get; set; } = null!;
        public virtual DbSet<Review> Reviews { get; set; } = null!;
        public virtual DbSet<ReviewStatus> ReviewStatuses { get; set; } = null!;
        public virtual DbSet<Role> Roles { get; set; } = null!;
        public virtual DbSet<Topic> Topics { get; set; } = null!;
        public virtual DbSet<TopicAssignment> TopicAssignments { get; set; } = null!;
        public virtual DbSet<TopicAttendance> TopicAttendances { get; set; } = null!;
        public virtual DbSet<TraineeFeedback> TraineeFeedbacks { get; set; } = null!;
        public virtual DbSet<User> Users { get; set; } = null!;
    }
}