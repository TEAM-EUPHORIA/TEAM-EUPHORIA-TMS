namespace TMS.Data.Interface
{
    public interface IUser
    {
        public User GetById(int id);
        public bool AddUser(User user);
        public bool UpdateUser(int id, User user);
        public bool DisableUser(int id, User user);
        public List<User> GetUsersByDepartment(int dept_id);
        public List<User> GetUsersByRole(int role_id);
    }
}