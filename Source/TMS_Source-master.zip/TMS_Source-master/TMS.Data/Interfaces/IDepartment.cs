namespace TMS.Data.Interface
{
public interface IDepartment
    {
        public List<Department> GetDepartments();
        public Department GetDepartment(int DepartmentId);
        public bool AddDepartment(Department department);
        public bool UpdateDepartment(int departmentId,Department department);
        public bool DeleteDepartment(int DepartmentId);
    }
}